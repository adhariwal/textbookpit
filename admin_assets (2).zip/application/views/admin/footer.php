<!-- end: Content -->
</div><!--/#content.span10-->
</div><!--/fluid-row-->
<div class="clearfix"></div>
<footer>
    <p>
        <span style="text-align:left;float:left">&copy; 2016 <a href="" alt=" Admin Dashboard">Classified Script v0.1</a> By <a href="http://www.greatwebidea.com" target="_blank">Great Web Idea</a></span>
    </p>
</footer>

<!-- start: JavaScript-->
<script src="<?php echo base_url();?>admin_assets/js/jquery-1.9.1.js"></script>
<script src="<?php echo base_url();?>admin_assets/js/jquery-migrate-1.1.0.js"></script>
<script src="<?php echo base_url();?>admin_assets/js/jquery-ui-1.10.0.custom.min.js"></script>



<script src="<?php echo base_url();?>admin_assets/js/bootstrap.js"></script>
<script src='<?php echo base_url();?>admin_assets/js/fullcalendar.min.js'></script>
<script src='<?php echo base_url();?>admin_assets/js/jquery.dataTables.js'></script>

<script src="<?php echo base_url();?>admin_assets/js/jquery.chosen.js"></script>
<script src="<?php echo base_url();?>admin_assets/js/jquery.uniform.js"></script>

<script src="<?php echo base_url();?>admin_assets/js/jquery.cleditor.min.js"></script>
<script src="<?php echo base_url();?>admin_assets/js/jquery.elfinder.min.js"></script>
<script src="<?php echo base_url();?>admin_assets/js/jquery.raty.js"></script>
<script src="<?php echo base_url();?>js/jquery.uploadify-3.1.min.js"></script>

<script src="<?php echo base_url();?>admin_assets/js/jquery.masonry.min.js"></script>
<script src="<?php echo base_url();?>admin_assets/js/jquery.knob.modified.js"></script>
<script src="<?php echo base_url();?>admin_assets/js/jquery.sparkline.min.js"></script>
<script src="<?php echo base_url();?>admin_assets/js/custom.js"></script>

<!-- end: JavaScript-->
	<!--<script language="JavaScript">
		  var data = '&r=' + escape(document.referrer)
			+ '&n=' + escape(navigator.userAgent)
			+ '&p=' + escape(navigator.userAgent)
			+ '&g=' + escape(document.location.href);

		  if (navigator.userAgent.substring(0,1)>'3')
			data = data + '&sd=' + screen.colorDepth
			+ '&sw=' + escape(screen.width+'x'+screen.height);

		  document.write('<a href="http://www.1freecounter.com/stats.php?i=87791" target=\"_blank\" >');
		  document.write('<img alt="Free Counter" border=0 hspace=0 '+'vspace=0 src="http://www.1freecounter.com/counter.php?i=87791' + data + '">');
		  document.write('</a>');
	</script>-->
</body>
</html>