<div class="container-fluid-full">
<div class="row-fluid">
<div id="sidebar-left" class="span2">
    <div class="nav-collapse sidebar-nav">
        <ul class="nav nav-tabs nav-stacked main-menu">


            <li class="active1"><a href="<?php echo base_url();?>index.php/admin/home"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Free Classified</span></a></li>
            <li><a href="<?php echo base_url();?>index.php/classifiedcategory"><i class="icon-tasks"></i><span class="hidden-tablet">Category</span></a></li>
            <li><a href="<?php echo base_url();?>index.php/classifiedsubcategory"><i class="icon-tasks"></i><span class="hidden-tablet">Sub Category</span></a></li>
            <li><a href="<?php echo base_url();?>index.php/classifiedads"><i class="icon-tasks"></i><span class="hidden-tablet">Ads</span></a></li>
            <li><a href="<?php echo base_url();?>index.php/classifiedads/getAllReview"><i class="icon-tasks"></i><span class="hidden-tablet">Ads Review</span></a></li>

            <li class="active1"><a href="<?php echo base_url();?>index.php/admin/home"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Deals Classified</span></a></li>
            <li><a href="<?php echo base_url();?>index.php/deals"><i class="icon-tasks"></i><span class="hidden-tablet">Deals Ads</span></a></li>

            <li class="active1"><a href="<?php echo base_url();?>index.php/admin/home"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Paid Ads Settings</span></a></li>
            <li><a href="<?php echo base_url();?>index.php/paidads"><i class="icon-tasks"></i><span class="hidden-tablet">Paid Ads</span></a></li>

            <li class="active1"><a href="<?php echo base_url();?>index.php/admin/home"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Baner Ads Settings</span></a></li>
            <li><a href="<?php echo base_url();?>index.php/banerads"><i class="icon-tasks"></i><span class="hidden-tablet">Baner Ads</span></a></li>
            
            <li class="active1"><a href="<?php echo base_url();?>index.php/admin/home"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Web Settings</span></a></li>
           <!-- <li><a href="<?php echo base_url();?>index.php/districts"><i class="icon-tasks"></i><span class="hidden-tablet">School Name</span></a></li>
            <li><a href="<?php echo base_url();?>index.php/area"><i class="icon-tasks"></i><span class="hidden-tablet">School Area</span></a></li>-->
            <li><a href="<?php echo base_url();?>index.php/pages"><i class="icon-tasks"></i><span class="hidden-tablet">Pages</span></a></li>
            <li><a href="<?php echo base_url();?>index.php/users"><i class="icon-tasks"></i><span class="hidden-tablet">Users</span></a></li>
            <li><a href="<?php echo base_url();?>index.php/profile"><i class="icon-tasks"></i><span class="hidden-tablet">Profile Settings</span></a></li>

            <!--<li>
                <a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Dropdown</span><span class="label label-important"> 3 </span></a>
                <ul>
                    <li><a class="submenu" href="submenu.html"><i class="icon-file-alt"></i><span class="hidden-tablet"> Sub Menu 1</span></a></li>
                    <li><a class="submenu" href="submenu2.html"><i class="icon-file-alt"></i><span class="hidden-tablet"> Sub Menu 2</span></a></li>
                    <li><a class="submenu" href="submenu3.html"><i class="icon-file-alt"></i><span class="hidden-tablet"> Sub Menu 3</span></a></li>
                </ul>
            </li>-->
            <li><a href="<?php echo base_url();?>index.php/admin/home/logout"><i class="icon-lock"></i><span class="hidden-tablet"> Logout</span></a></li>
        </ul>
    </div>
</div>