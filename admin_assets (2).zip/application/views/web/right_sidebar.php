<!--<br><br><h5>&nbsp;&nbsp;<a href="<?php echo base_url(); ?>index.php/webdetails/post" class="btn btn-danger">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Post Ad&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h5>-->

          <div class="newest-classifieds">
            <div class="media">
              <a class="pull-left" href="#">
                <img class="media-object" style="width: 170px; height: 150px;" src="<?php echo base_url().'uploads/paidads/promo.jpg'; ?>" />
              </a>
              <div class="media-body">
                <p><a href="#"><strong></strong></a></p>
                <p></p>
              </div>
            </div>
            
          </div>
